<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'fruitkha' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '36:N,hJw-%[P CVY.04;KIWN5kdTy@vg?rP!zgUWU_ZFAcn6E+=5>s,Fu73olF0C' );
define( 'SECURE_AUTH_KEY',  '!Hz9eE8iNdZ9:xX 9I?r~> }Ko[by!?@X1>|E]NfHe(0edq7Z!5.%[&[qC>tBQJk' );
define( 'LOGGED_IN_KEY',    '_rrGE#i7NE@!>%0D59&hnsv3H .YG^f()(e$pkSmf8T0#P~p89{;_4/qpWGRZDP)' );
define( 'NONCE_KEY',        'lZueHZ4OXU/MO%#H(qU_JkHI,%[xl9e}J5D>Wv}yj?WTi>!skm}5{t<yXqRY&vjs' );
define( 'AUTH_SALT',        'SA<7y@`|0V4f)$25J~2&C@Sh8{k$jfj%eG4mv`|Av=ECdU,OY+Q6pi|^u}lv/`V+' );
define( 'SECURE_AUTH_SALT', 'xmEu~:u`dcq0gFYVt6wO=|^jJN h^>&+%uym b%<uXF:M^^ouHMA0,gx-Z&bsz&,' );
define( 'LOGGED_IN_SALT',   '!QN1:pqF:cU*Nx+Kh>q0sj~!:j4I5_u2o0< gbroZ5;#4d=Nx`(z7&j-o>:^G(Qm' );
define( 'NONCE_SALT',       ']j,P]HL]66c!*w.$D5psjEy]q1#t[[{E;9c!v %e$$Fwn m^_>5.h0c3+rkfqa^;' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
